## Environment

Replace this text with the Version of your operating system, your exact browser version, the used Adblock Plus version and the enabled Filter lists.

## How to reproduce

1. Step one of your reproduction process (e.g: Go to http://example.com/
2. Step two of your reproduction process (e.g: Click the big red button labelled "click me" at the left)
3. Step three of your reproduction process
4. Step four of your reproduction process
...

## Observed behavior

Replace this text with your detailed observations.

## Expected behavior

Replace this text with your detailed expectations.

/label ~bug
